package com.example.dailyinsight.data.model

data class PricePoint(val date: String, val close: Double)