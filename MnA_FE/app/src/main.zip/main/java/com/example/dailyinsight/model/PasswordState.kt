package com.example.dailyinsight.model

enum class PasswordState {
    VALID, TOO_SHORT, TOO_LONG, NO_UPPERCASE, NO_LOWERCASE, NO_DIGIT
}