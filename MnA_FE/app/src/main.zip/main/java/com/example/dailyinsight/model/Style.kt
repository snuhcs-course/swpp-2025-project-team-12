package com.example.dailyinsight.model

enum class Style {
    STABLE,
    AGGRESSIVE,
    NEUTRAL,
    NONE
}