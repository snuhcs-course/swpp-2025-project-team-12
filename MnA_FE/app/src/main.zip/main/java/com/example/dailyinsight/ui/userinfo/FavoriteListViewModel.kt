package com.example.dailyinsight.ui.userinfo

class FavoriteListViewModel {
}