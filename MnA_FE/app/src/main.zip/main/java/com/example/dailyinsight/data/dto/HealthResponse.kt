package com.example.dailyinsight.data.dto

data class HealthResponse(
    val status: String,          // "ok"
    val timestamp: String        // "2025-10-15T05:19:00Z"
)